Faizel Quabili
CISC442
Homework 7

hw7functions.py
- Contains functions required for homework and main.py

main.py
- Contains function calls from hw7functions.py to output images